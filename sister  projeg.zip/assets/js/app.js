// Global variables
let currentMonth = new Date();
let currentUser = null;
let transactions = [];
let categories = [];
let charts = {};

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    setupEventListeners();
    loadCategories();
    loadDashboard();
});

// Initialize application
function initializeApp() {
    updateMonthDisplay();
    setupNavigation();
    
    // Set default date to today
    document.getElementById('transaction-date').value = new Date().toISOString().split('T')[0];
    
    // Set current month for filters
    document.getElementById('filter-month').value = formatMonth(currentMonth);
}

// Setup event listeners
function setupEventListeners() {
    // Navigation
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const section = this.getAttribute('data-section');
            showSection(section);
        });
    });
    
    // Transaction form
    document.getElementById('transaction-form').addEventListener('submit', handleTransactionSubmit);
    
    // Category form
    document.getElementById('category-form').addEventListener('submit', handleCategorySubmit);
    
    // Transaction type change
    document.getElementById('transaction-type').addEventListener('change', updateCategoryOptions);
    
    // Modal close on outside click
    document.querySelectorAll('.modal').forEach(modal => {
        modal.addEventListener('click', function(e) {
            if (e.target === this) {
                this.classList.remove('active');
            }
        });
    });
}

// Navigation functions
function setupNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', function() {
            navLinks.forEach(l => l.classList.remove('active'));
            this.classList.add('active');
        });
    });
}

function showSection(sectionName) {
    // Hide all sections
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
    });
    
    // Show selected section
    document.getElementById(sectionName).classList.add('active');
    
    // Load section data
    switch(sectionName) {
        case 'dashboard':
            loadDashboard();
            break;
        case 'transactions':
            loadTransactions();
            break;
        case 'categories':
            loadCategories();
            break;
        case 'reports':
            generateReports();
            break;
    }
}

// Month navigation
function changeMonth(direction) {
    currentMonth.setMonth(currentMonth.getMonth() + direction);
    updateMonthDisplay();
    loadDashboard();
}

function updateMonthDisplay() {
    const monthNames = [
        'January', 'February', 'March', 'April', 'May', 'June',
        'July', 'August', 'September', 'October', 'November', 'December'
    ];
    
    const monthYear = `${monthNames[currentMonth.getMonth()]} ${currentMonth.getFullYear()}`;
    document.getElementById('current-month').textContent = monthYear;
}

function formatMonth(date) {
    return date.getFullYear() + '-' + String(date.getMonth() + 1).padStart(2, '0');
}

// API Functions
async function apiCall(endpoint, method = 'GET', data = null) {
    showLoading(true);
    
    try {
        const options = {
            method: method,
            headers: {
                'Content-Type': 'application/json',
            }
        };
        
        if (data) {
            options.body = JSON.stringify(data);
        }
        
        const response = await fetch(`api/${endpoint}`, options);
        const result = await response.json();
        
        if (!result.success) {
            throw new Error(result.message);
        }
        
        return result;
    } catch (error) {
        console.error('API Error:', error);
        alert('Error: ' + error.message);
        throw error;
    } finally {
        showLoading(false);
    }
}

// Loading overlay
function showLoading(show) {
    const overlay = document.getElementById('loading');
    overlay.classList.toggle('active', show);
}

// Dashboard functions
async function loadDashboard() {
    try {
        const month = formatMonth(currentMonth);
        const response = await apiCall(`transactions.php?action=stats&month=${month}`);
        const stats = response.data;
        
        updateStatsCards(stats);
        updateRecentTransactions();
        updateCharts(stats);
    } catch (error) {
        console.error('Error loading dashboard:', error);
    }
}

function updateStatsCards(stats) {
    document.getElementById('total-income').textContent = formatCurrency(stats.total_income || 0);
    document.getElementById('total-expense').textContent = formatCurrency(stats.total_expense || 0);
    document.getElementById('balance').textContent = formatCurrency((stats.total_income || 0) - (stats.total_expense || 0));
    document.getElementById('transaction-count').textContent = (stats.income_count || 0) + (stats.expense_count || 0);
}

function updateRecentTransactions() {
    loadTransactions(true);
}

function updateCharts(stats) {
    updateTrendsChart(stats.monthly_trends || []);
    updateExpenseChart(stats.category_breakdown || []);
}

function updateTrendsChart(trends) {
    const ctx = document.getElementById('trendsChart').getContext('2d');
    
    if (charts.trends) {
        charts.trends.destroy();
    }
    
    const months = trends.map(t => t.month);
    const incomeData = trends.map(t => parseFloat(t.income) || 0);
    const expenseData = trends.map(t => parseFloat(t.expense) || 0);
    
    charts.trends = new Chart(ctx, {
        type: 'line',
        data: {
            labels: months,
            datasets: [{
                label: 'Income',
                data: incomeData,
                borderColor: '#28a745',
                backgroundColor: 'rgba(40, 167, 69, 0.1)',
                tension: 0.4
            }, {
                label: 'Expense',
                data: expenseData,
                borderColor: '#dc3545',
                backgroundColor: 'rgba(220, 53, 69, 0.1)',
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return '$' + value.toLocaleString();
                        }
                    }
                }
            }
        }
    });
}

function updateExpenseChart(categoryBreakdown) {
    const ctx = document.getElementById('expenseChart').getContext('2d');
    
    if (charts.expense) {
        charts.expense.destroy();
    }
    
    const expenseCategories = categoryBreakdown.filter(c => c.type === 'expense');
    
    if (expenseCategories.length === 0) {
        charts.expense = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['No Data'],
                datasets: [{
                    data: [1],
                    backgroundColor: ['#e9ecef']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                    }
                }
            }
        });
        return;
    }
    
    const labels = expenseCategories.map(c => c.name);
    const data = expenseCategories.map(c => parseFloat(c.total) || 0);
    const colors = expenseCategories.map(c => c.color);
    
    charts.expense = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: labels,
            datasets: [{
                data: data,
                backgroundColor: colors
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                }
            }
        }
    });
}

// Transactions functions
async function loadTransactions(recentOnly = false) {
    try {
        const month = recentOnly ? formatMonth(currentMonth) : (document.getElementById('filter-month').value || formatMonth(currentMonth));
        const type = document.getElementById('filter-type').value || '';
        const category = document.getElementById('filter-category').value || '';
        
        let endpoint = `transactions.php?action=list&month=${month}`;
        if (type) endpoint += `&type=${type}`;
        if (category) endpoint += `&category=${category}`;
        
        const response = await apiCall(endpoint);
        transactions = response.data;
        
        displayTransactions(transactions, recentOnly);
    } catch (error) {
        console.error('Error loading transactions:', error);
    }
}

function displayTransactions(transactions, recentOnly = false) {
    const container = recentOnly ? 
        document.getElementById('recent-transactions-list') : 
        document.getElementById('transactions-list');
    
    if (transactions.length === 0) {
        container.innerHTML = '<div class="no-data">No transactions found</div>';
        return;
    }
    
    // Limit to 5 for recent transactions
    const displayTransactions = recentOnly ? transactions.slice(0, 5) : transactions;
    
    container.innerHTML = displayTransactions.map(transaction => `
        <div class="transaction-item">
            <div class="transaction-info">
                <div class="transaction-icon" style="background: ${transaction.category_color || '#007bff'}">
                    <i class="fas ${transaction.type === 'income' ? 'fa-arrow-up' : 'fa-arrow-down'}"></i>
                </div>
                <div class="transaction-details">
                    <h4>${transaction.description}</h4>
                    <p>${transaction.category_name || 'Uncategorized'} • ${formatDate(transaction.date)}</p>
                </div>
            </div>
            <div class="transaction-amount ${transaction.type}">
                ${transaction.type === 'income' ? '+' : '-'}${formatCurrency(transaction.amount)}
            </div>
            ${!recentOnly ? `
                <div class="transaction-actions">
                    <button class="btn-edit" onclick="editTransaction(${transaction.id})">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn-delete" onclick="deleteTransaction(${transaction.id})">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            ` : ''}
        </div>
    `).join('');
}

function filterTransactions() {
    loadTransactions();
}

// Transaction modal functions
function showTransactionModal(transactionId = null) {
    const modal = document.getElementById('transaction-modal');
    const title = document.getElementById('transaction-modal-title');
    const form = document.getElementById('transaction-form');
    
    if (transactionId) {
        const transaction = transactions.find(t => t.id === transactionId);
        if (transaction) {
            title.textContent = 'Edit Transaction';
            document.getElementById('transaction-id').value = transaction.id;
            document.getElementById('transaction-type').value = transaction.type;
            document.getElementById('transaction-category').value = transaction.category_id || '';
            document.getElementById('transaction-amount').value = transaction.amount;
            document.getElementById('transaction-description').value = transaction.description;
            document.getElementById('transaction-date').value = transaction.date;
            
            updateCategoryOptions();
        }
    } else {
        title.textContent = 'Add Transaction';
        form.reset();
        document.getElementById('transaction-date').value = new Date().toISOString().split('T')[0];
    }
    
    modal.classList.add('active');
}

function hideTransactionModal() {
    document.getElementById('transaction-modal').classList.remove('active');
}

async function handleTransactionSubmit(e) {
    e.preventDefault();
    
    const transactionId = document.getElementById('transaction-id').value;
    const data = {
        type: document.getElementById('transaction-type').value,
        category_id: document.getElementById('transaction-category').value,
        amount: parseFloat(document.getElementById('transaction-amount').value),
        description: document.getElementById('transaction-description').value,
        date: document.getElementById('transaction-date').value
    };
    
    try {
        if (transactionId) {
            data.id = parseInt(transactionId);
            await apiCall('transactions.php', 'PUT', data);
            alert('Transaction updated successfully!');
        } else {
            await apiCall('transactions.php?action=add', 'POST', data);
            alert('Transaction added successfully!');
        }
        
        hideTransactionModal();
        loadDashboard();
        if (document.getElementById('transactions').classList.contains('active')) {
            loadTransactions();
        }
    } catch (error) {
        console.error('Error saving transaction:', error);
    }
}

async function editTransaction(id) {
    showTransactionModal(id);
}

async function deleteTransaction(id) {
    if (confirm('Are you sure you want to delete this transaction?')) {
        try {
            await apiCall(`transactions.php?id=${id}`, 'DELETE');
            alert('Transaction deleted successfully!');
            loadDashboard();
            if (document.getElementById('transactions').classList.contains('active')) {
                loadTransactions();
            }
        } catch (error) {
            console.error('Error deleting transaction:', error);
        }
    }
}

// Categories functions
async function loadCategories() {
    try {
        const response = await apiCall('categories.php');
        categories = response.data;
        displayCategories();
        updateCategoryFilters();
    } catch (error) {
        console.error('Error loading categories:', error);
    }
}

function displayCategories() {
    const incomeContainer = document.getElementById('income-categories');
    const expenseContainer = document.getElementById('expense-categories');
    
    const incomeCategories = categories.filter(c => c.type === 'income');
    const expenseCategories = categories.filter(c => c.type === 'expense');
    
    incomeContainer.innerHTML = incomeCategories.map(category => `
        <div class="category-item">
            <div class="category-info">
                <div class="category-color" style="background: ${category.color}"></div>
                <span>${category.name}</span>
            </div>
            <div class="category-actions">
                <button class="btn-edit" onclick="editCategory(${category.id})">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn-delete" onclick="deleteCategory(${category.id})">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
    `).join('');
    
    expenseContainer.innerHTML = expenseCategories.map(category => `
        <div class="category-item">
            <div class="category-info">
                <div class="category-color" style="background: ${category.color}"></div>
                <span>${category.name}</span>
            </div>
            <div class="category-actions">
                <button class="btn-edit" onclick="editCategory(${category.id})">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn-delete" onclick="deleteCategory(${category.id})">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
    `).join('');
}

function updateCategoryFilters() {
    const filterSelect = document.getElementById('filter-category');
    const transactionSelect = document.getElementById('transaction-category');
    
    filterSelect.innerHTML = '<option value="">All Categories</option>';
    transactionSelect.innerHTML = '<option value="">Select Category</option>';
    
    categories.forEach(category => {
        const option = `<option value="${category.id}">${category.name}</option>`;
        filterSelect.innerHTML += option;
        transactionSelect.innerHTML += option;
    });
}

function updateCategoryOptions() {
    const type = document.getElementById('transaction-type').value;
    const categorySelect = document.getElementById('transaction-category');
    
    categorySelect.innerHTML = '<option value="">Select Category</option>';
    
    if (type) {
        const filteredCategories = categories.filter(c => c.type === type);
        filteredCategories.forEach(category => {
            categorySelect.innerHTML += `<option value="${category.id}">${category.name}</option>`;
        });
    }
}

// Category modal functions
function showCategoryModal(categoryId = null) {
    const modal = document.getElementById('category-modal');
    const title = document.getElementById('category-modal-title');
    const form = document.getElementById('category-form');
    
    if (categoryId) {
        const category = categories.find(c => c.id === categoryId);
        if (category) {
            title.textContent = 'Edit Category';
            document.getElementById('category-id').value = category.id;
            document.getElementById('category-name').value = category.name;
            document.getElementById('category-type').value = category.type;
            document.getElementById('category-color').value = category.color;
        }
    } else {
        title.textContent = 'Add Category';
        form.reset();
        document.getElementById('category-color').value = '#007bff';
    }
    
    modal.classList.add('active');
}

function hideCategoryModal() {
    document.getElementById('category-modal').classList.remove('active');
}

async function handleCategorySubmit(e) {
    e.preventDefault();
    
    const categoryId = document.getElementById('category-id').value;
    const data = {
        name: document.getElementById('category-name').value,
        type: document.getElementById('category-type').value,
        color: document.getElementById('category-color').value
    };
    
    try {
        if (categoryId) {
            data.id = parseInt(categoryId);
            await apiCall('categories.php', 'PUT', data);
            alert('Category updated successfully!');
        } else {
            await apiCall('categories.php', 'POST', data);
            alert('Category created successfully!');
        }
        
        hideCategoryModal();
        loadCategories();
    } catch (error) {
        console.error('Error saving category:', error);
    }
}

async function editCategory(id) {
    showCategoryModal(id);
}

async function deleteCategory(id) {
    if (confirm('Are you sure you want to delete this category?')) {
        try {
            await apiCall(`categories.php?id=${id}`, 'DELETE');
            alert('Category deleted successfully!');
            loadCategories();
        } catch (error) {
            console.error('Error deleting category:', error);
        }
    }
}

// Reports functions
async function generateReports() {
    // This would typically load annual data
    // For now, we'll use the existing monthly data
    updateAnnualChart();
    updateCategoryAnalysisChart();
}

function updateAnnualChart() {
    const ctx = document.getElementById('annualChart').getContext('2d');
    
    if (charts.annual) {
        charts.annual.destroy();
    }
    
    // Sample data - in a real app, this would come from the API
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
    const incomeData = [5000, 5200, 4800, 5500, 6000, 5800];
    const expenseData = [3500, 3800, 3200, 4000, 4200, 3900];
    
    charts.annual = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: months,
            datasets: [{
                label: 'Income',
                data: incomeData,
                backgroundColor: 'rgba(40, 167, 69, 0.8)',
                borderColor: '#28a745',
                borderWidth: 1
            }, {
                label: 'Expense',
                data: expenseData,
                backgroundColor: 'rgba(220, 53, 69, 0.8)',
                borderColor: '#dc3545',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return '$' + value.toLocaleString();
                        }
                    }
                }
            }
        }
    });
}

function updateCategoryAnalysisChart() {
    const ctx = document.getElementById('categoryChart').getContext('2d');
    
    if (charts.categoryAnalysis) {
        charts.categoryAnalysis.destroy();
    }
    
    // Sample data - in a real app, this would come from the API
    const categories = ['Food', 'Transportation', 'Entertainment', 'Shopping', 'Bills'];
    const amounts = [1200, 800, 600, 1000, 1500];
    
    charts.categoryAnalysis = new Chart(ctx, {
        type: 'polarArea',
        data: {
            labels: categories,
            datasets: [{
                data: amounts,
                backgroundColor: [
                    'rgba(255, 99, 132, 0.8)',
                    'rgba(54, 162, 235, 0.8)',
                    'rgba(255, 205, 86, 0.8)',
                    'rgba(75, 192, 192, 0.8)',
                    'rgba(153, 102, 255, 0.8)'
                ],
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                }
            }
        }
    });
}

// Utility functions
function formatCurrency(amount) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD'
    }).format(amount);
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}

function logout() {
    if (confirm('Are you sure you want to logout?')) {
        // In a real app, this would clear session/token
        alert('Logout functionality would be implemented here');
    }
}

// Initialize sample data (for demo purposes)
function initializeSampleData() {
    // This function would be called to create sample transactions
    // for demonstration purposes
    console.log('Sample data initialization would go here');
}
