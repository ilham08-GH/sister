<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

$input = json_decode(file_get_contents('php://input'), true);

function sendResponse($success, $message, $data = null) {
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data' => $data
    ]);
    exit;
}

// For demo purposes, we'll use a default user_id
$user_id = 1;

try {
    $pdo = getDBConnection();
    
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $action = $_GET['action'] ?? 'list';
        
        if ($action === 'list') {
            $month = $_GET['month'] ?? date('Y-m');
            $type = $_GET['type'] ?? '';
            
            $query = "SELECT t.*, c.name as category_name, c.color as category_color 
                     FROM transactions t 
                     LEFT JOIN categories c ON t.category_id = c.id 
                     WHERE t.user_id = ? AND DATE_FORMAT(t.date, '%Y-%m') = ?";
            $params = [$user_id, $month];
            
            if (!empty($type)) {
                $query .= " AND t.type = ?";
                $params[] = $type;
            }
            
            $query .= " ORDER BY t.date DESC, t.created_at DESC";
            
            $stmt = $pdo->prepare($query);
            $stmt->execute($params);
            $transactions = $stmt->fetchAll();
            
            sendResponse(true, 'Transactions retrieved successfully', $transactions);
        }
        
        if ($action === 'stats') {
            $month = $_GET['month'] ?? date('Y-m');
            
            // Get monthly stats
            $stmt = $pdo->prepare("
                SELECT 
                    SUM(CASE WHEN type = 'income' THEN amount ELSE 0 END) as total_income,
                    SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END) as total_expense,
                    COUNT(CASE WHEN type = 'income' THEN 1 END) as income_count,
                    COUNT(CASE WHEN type = 'expense' THEN 1 END) as expense_count
                FROM transactions 
                WHERE user_id = ? AND DATE_FORMAT(date, '%Y-%m') = ?
            ");
            $stmt->execute([$user_id, $month]);
            $stats = $stmt->fetch();
            
            // Get category breakdown
            $stmt = $pdo->prepare("
                SELECT c.name, c.color, SUM(t.amount) as total, t.type
                FROM transactions t
                LEFT JOIN categories c ON t.category_id = c.id
                WHERE t.user_id = ? AND DATE_FORMAT(t.date, '%Y-%m') = ?
                GROUP BY c.id, t.type
                ORDER BY total DESC
            ");
            $stmt->execute([$user_id, $month]);
            $categoryStats = $stmt->fetchAll();
            
            // Get monthly trend (last 6 months)
            $stmt = $pdo->prepare("
                SELECT 
                    DATE_FORMAT(date, '%Y-%m') as month,
                    SUM(CASE WHEN type = 'income' THEN amount ELSE 0 END) as income,
                    SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END) as expense
                FROM transactions 
                WHERE user_id = ? AND date >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
                GROUP BY DATE_FORMAT(date, '%Y-%m')
                ORDER BY month
            ");
            $stmt->execute([$user_id]);
            $trends = $stmt->fetchAll();
            
            $stats['category_breakdown'] = $categoryStats;
            $stats['monthly_trends'] = $trends;
            
            sendResponse(true, 'Stats retrieved successfully', $stats);
        }
    }
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $action = $_GET['action'] ?? 'add';
        
        if ($action === 'add') {
            $amount = floatval($input['amount'] ?? 0);
            $description = $input['description'] ?? '';
            $type = $input['type'] ?? '';
            $category_id = intval($input['category_id'] ?? 0);
            $date = $input['date'] ?? date('Y-m-d');
            
            if ($amount <= 0) {
                sendResponse(false, 'Amount must be greater than 0');
            }
            
            if (!in_array($type, ['income', 'expense'])) {
                sendResponse(false, 'Invalid transaction type');
            }
            
            if (empty($description)) {
                sendResponse(false, 'Description is required');
            }
            
            $stmt = $pdo->prepare("INSERT INTO transactions (user_id, category_id, amount, description, type, date) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$user_id, $category_id, $amount, $description, $type, $date]);
            
            sendResponse(true, 'Transaction added successfully', ['id' => $pdo->lastInsertId()]);
        }
    }
    
    if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
        $id = intval($input['id'] ?? 0);
        $amount = floatval($input['amount'] ?? 0);
        $description = $input['description'] ?? '';
        $type = $input['type'] ?? '';
        $category_id = intval($input['category_id'] ?? 0);
        $date = $input['date'] ?? '';
        
        if ($id <= 0) {
            sendResponse(false, 'Invalid transaction ID');
        }
        
        if ($amount <= 0) {
            sendResponse(false, 'Amount must be greater than 0');
        }
        
        if (!in_array($type, ['income', 'expense'])) {
            sendResponse(false, 'Invalid transaction type');
        }
        
        $stmt = $pdo->prepare("UPDATE transactions SET amount = ?, description = ?, type = ?, category_id = ?, date = ? WHERE id = ? AND user_id = ?");
        $stmt->execute([$amount, $description, $type, $category_id, $date, $id, $user_id]);
        
        if ($stmt->rowCount() > 0) {
            sendResponse(true, 'Transaction updated successfully');
        } else {
            sendResponse(false, 'Transaction not found or update failed');
        }
    }
    
    if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
        $id = intval($_GET['id'] ?? 0);
        
        if ($id <= 0) {
            sendResponse(false, 'Invalid transaction ID');
        }
        
        $stmt = $pdo->prepare("DELETE FROM transactions WHERE id = ? AND user_id = ?");
        $stmt->execute([$id, $user_id]);
        
        if ($stmt->rowCount() > 0) {
            sendResponse(true, 'Transaction deleted successfully');
        } else {
            sendResponse(false, 'Transaction not found or delete failed');
        }
    }
    
} catch (Exception $e) {
    sendResponse(false, 'Database error: ' . $e->getMessage());
}

sendResponse(false, 'Invalid request');
?>
