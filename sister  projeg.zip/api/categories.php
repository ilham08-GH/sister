<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

$input = json_decode(file_get_contents('php://input'), true);

function sendResponse($success, $message, $data = null) {
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data' => $data
    ]);
    exit;
}

try {
    $pdo = getDBConnection();
    
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $type = $_GET['type'] ?? '';
        
        $query = "SELECT * FROM categories";
        $params = [];
        
        if (!empty($type) && in_array($type, ['income', 'expense'])) {
            $query .= " WHERE type = ?";
            $params[] = $type;
        }
        
        $query .= " ORDER BY name";
        
        $stmt = $pdo->prepare($query);
        $stmt->execute($params);
        $categories = $stmt->fetchAll();
        
        sendResponse(true, 'Categories retrieved successfully', $categories);
    }
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $name = trim($input['name'] ?? '');
        $type = $input['type'] ?? '';
        $color = $input['color'] ?? '#007bff';
        
        if (empty($name)) {
            sendResponse(false, 'Category name is required');
        }
        
        if (!in_array($type, ['income', 'expense'])) {
            sendResponse(false, 'Invalid category type');
        }
        
        // Check if category already exists
        $stmt = $pdo->prepare("SELECT id FROM categories WHERE name = ? AND type = ?");
        $stmt->execute([$name, $type]);
        if ($stmt->fetch()) {
            sendResponse(false, 'Category already exists');
        }
        
        $stmt = $pdo->prepare("INSERT INTO categories (name, type, color) VALUES (?, ?, ?)");
        $stmt->execute([$name, $type, $color]);
        
        sendResponse(true, 'Category created successfully', ['id' => $pdo->lastInsertId()]);
    }
    
    if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
        $id = intval($input['id'] ?? 0);
        $name = trim($input['name'] ?? '');
        $type = $input['type'] ?? '';
        $color = $input['color'] ?? '#007bff';
        
        if ($id <= 0) {
            sendResponse(false, 'Invalid category ID');
        }
        
        if (empty($name)) {
            sendResponse(false, 'Category name is required');
        }
        
        if (!in_array($type, ['income', 'expense'])) {
            sendResponse(false, 'Invalid category type');
        }
        
        // Check if category already exists (excluding current)
        $stmt = $pdo->prepare("SELECT id FROM categories WHERE name = ? AND type = ? AND id != ?");
        $stmt->execute([$name, $type, $id]);
        if ($stmt->fetch()) {
            sendResponse(false, 'Category already exists');
        }
        
        $stmt = $pdo->prepare("UPDATE categories SET name = ?, type = ?, color = ? WHERE id = ?");
        $stmt->execute([$name, $type, $color, $id]);
        
        if ($stmt->rowCount() > 0) {
            sendResponse(true, 'Category updated successfully');
        } else {
            sendResponse(false, 'Category not found or update failed');
        }
    }
    
    if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
        $id = intval($_GET['id'] ?? 0);
        
        if ($id <= 0) {
            sendResponse(false, 'Invalid category ID');
        }
        
        // Check if category is being used in transactions
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM transactions WHERE category_id = ?");
        $stmt->execute([$id]);
        $count = $stmt->fetchColumn();
        
        if ($count > 0) {
            sendResponse(false, 'Cannot delete category that is being used in transactions');
        }
        
        $stmt = $pdo->prepare("DELETE FROM categories WHERE id = ?");
        $stmt->execute([$id]);
        
        if ($stmt->rowCount() > 0) {
            sendResponse(true, 'Category deleted successfully');
        } else {
            sendResponse(false, 'Category not found or delete failed');
        }
    }
    
} catch (Exception $e) {
    sendResponse(false, 'Database error: ' . $e->getMessage());
}

sendResponse(false, 'Invalid request');
?>
