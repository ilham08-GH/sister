<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/database.php';

// Initialize database
initDatabase();

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

$input = json_decode(file_get_contents('php://input'), true);

function sendResponse($success, $message, $data = null) {
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data' => $data
    ]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_GET['action'] ?? '';
    
    if ($action === 'register') {
        $username = $input['username'] ?? '';
        $email = $input['email'] ?? '';
        $password = $input['password'] ?? '';
        
        if (empty($username) || empty($email) || empty($password)) {
            sendResponse(false, 'All fields are required');
        }
        
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            sendResponse(false, 'Invalid email format');
        }
        
        if (strlen($password) < 6) {
            sendResponse(false, 'Password must be at least 6 characters');
        }
        
        try {
            $pdo = getDBConnection();
            
            // Check if user exists
            $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
            $stmt->execute([$username, $email]);
            if ($stmt->fetch()) {
                sendResponse(false, 'Username or email already exists');
            }
            
            // Create user
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
            $stmt->execute([$username, $email, $hashedPassword]);
            
            sendResponse(true, 'User registered successfully', ['user_id' => $pdo->lastInsertId()]);
            
        } catch (Exception $e) {
            sendResponse(false, 'Registration failed: ' . $e->getMessage());
        }
    }
    
    if ($action === 'login') {
        $username = $input['username'] ?? '';
        $password = $input['password'] ?? '';
        
        if (empty($username) || empty($password)) {
            sendResponse(false, 'Username and password are required');
        }
        
        try {
            $pdo = getDBConnection();
            
            $stmt = $pdo->prepare("SELECT id, username, email, password FROM users WHERE username = ? OR email = ?");
            $stmt->execute([$username, $username]);
            $user = $stmt->fetch();
            
            if ($user && password_verify($password, $user['password'])) {
                unset($user['password']); // Remove password from response
                sendResponse(true, 'Login successful', $user);
            } else {
                sendResponse(false, 'Invalid username or password');
            }
            
        } catch (Exception $e) {
            sendResponse(false, 'Login failed: ' . $e->getMessage());
        }
    }
}

sendResponse(false, 'Invalid request method');
?>
