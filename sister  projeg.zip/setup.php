<?php
require_once 'config/database.php';

// Initialize database and create sample data
function setupSystem() {
    try {
        // Initialize database
        if (initDatabase()) {
            echo "Database initialized successfully!\n";
            
            // Create sample user
            createSampleUser();
            
            // Create sample transactions
            createSampleTransactions();
            
            echo "System setup completed successfully!\n";
            echo "You can now access the application at: index.html\n";
        } else {
            echo "Failed to initialize database!\n";
        }
    } catch (Exception $e) {
        echo "Setup failed: " . $e->getMessage() . "\n";
    }
}

function createSampleUser() {
    try {
        $pdo = getDBConnection();
        
        // Check if user already exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute(['demo']);
        
        if (!$stmt->fetch()) {
            $hashedPassword = password_hash('demo123', PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
            $stmt->execute(['demo', 'demo@example.com', $hashedPassword]);
            echo "Sample user created (username: demo, password: demo123)\n";
        } else {
            echo "Sample user already exists\n";
        }
    } catch (Exception $e) {
        echo "Error creating sample user: " . $e->getMessage() . "\n";
    }
}

function createSampleTransactions() {
    try {
        $pdo = getDBConnection();
        
        // Check if transactions already exist
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM transactions WHERE user_id = 1");
        $stmt->execute();
        $count = $stmt->fetchColumn();
        
        if ($count == 0) {
            // Get category IDs
            $categories = [];
            $stmt = $pdo->prepare("SELECT id, name, type FROM categories");
            $stmt->execute();
            while ($row = $stmt->fetch()) {
                $categories[$row['name']] = $row['id'];
            }
            
            // Sample transactions for the current month
            $currentMonth = date('Y-m');
            $sampleTransactions = [
                // Income transactions
                ['amount' => 3500.00, 'description' => 'Monthly Salary', 'type' => 'income', 'category' => 'Salary', 'date' => $currentMonth . '-01'],
                ['amount' => 500.00, 'description' => 'Freelance Project', 'type' => 'income', 'category' => 'Freelance', 'date' => $currentMonth . '-05'],
                ['amount' => 200.00, 'description' => 'Investment Returns', 'type' => 'income', 'category' => 'Investment', 'date' => $currentMonth . '-10'],
                
                // Expense transactions
                ['amount' => 800.00, 'description' => 'Grocery Shopping', 'type' => 'expense', 'category' => 'Food', 'date' => $currentMonth . '-02'],
                ['amount' => 150.00, 'description' => 'Gas Bill', 'type' => 'expense', 'category' => 'Bills', 'date' => $currentMonth . '-03'],
                ['amount' => 300.00, 'description' => 'Movie Tickets', 'type' => 'expense', 'category' => 'Entertainment', 'date' => $currentMonth . '-04'],
                ['amount' => 120.00, 'description' => 'Uber Rides', 'type' => 'expense', 'category' => 'Transportation', 'date' => $currentMonth . '-06'],
                ['amount' => 250.00, 'description' => 'New Shoes', 'type' => 'expense', 'category' => 'Shopping', 'date' => $currentMonth . '-08'],
                ['amount' => 180.00, 'description' => 'Doctor Visit', 'type' => 'expense', 'category' => 'Healthcare', 'date' => $currentMonth . '-12'],
                ['amount' => 600.00, 'description' => 'Rent Payment', 'type' => 'expense', 'category' => 'Bills', 'date' => $currentMonth . '-15'],
                ['amount' => 90.00, 'description' => 'Restaurant Dinner', 'type' => 'expense', 'category' => 'Food', 'date' => $currentMonth . '-18'],
                ['amount' => 75.00, 'description' => 'Netflix Subscription', 'type' => 'expense', 'category' => 'Entertainment', 'date' => $currentMonth . '-20'],
            ];
            
            // Add some transactions from previous months
            $prevMonth = date('Y-m', strtotime('-1 month'));
            $prevMonthTransactions = [
                ['amount' => 3500.00, 'description' => 'Monthly Salary', 'type' => 'income', 'category' => 'Salary', 'date' => $prevMonth . '-01'],
                ['amount' => 750.00, 'description' => 'Grocery Shopping', 'type' => 'expense', 'category' => 'Food', 'date' => $prevMonth . '-05'],
                ['amount' => 200.00, 'description' => 'Electricity Bill', 'type' => 'expense', 'category' => 'Bills', 'date' => $prevMonth . '-10'],
                ['amount' => 400.00, 'description' => 'Online Shopping', 'type' => 'expense', 'category' => 'Shopping', 'date' => $prevMonth . '-15'],
            ];
            
            $allTransactions = array_merge($sampleTransactions, $prevMonthTransactions);
            
            $stmt = $pdo->prepare("INSERT INTO transactions (user_id, category_id, amount, description, type, date) VALUES (?, ?, ?, ?, ?, ?)");
            
            foreach ($allTransactions as $transaction) {
                $categoryId = $categories[$transaction['category']] ?? null;
                $stmt->execute([1, $categoryId, $transaction['amount'], $transaction['description'], $transaction['type'], $transaction['date']]);
            }
            
            echo "Sample transactions created successfully!\n";
        } else {
            echo "Sample transactions already exist\n";
        }
    } catch (Exception $e) {
        echo "Error creating sample transactions: " . $e->getMessage() . "\n";
    }
}

// Run setup
setupSystem();
?>
