# Financial Management System

A complete web-based financial management system built with HTML, CSS, JavaScript, and PHP. This system allows users to track income and expenses, manage categories, and view detailed reports with beautiful charts.

## Features

### 📊 Dashboard
- Monthly overview with income, expense, and balance statistics
- Interactive charts showing monthly trends
- Expense category breakdown with pie charts
- Recent transactions list

### 💰 Transaction Management
- Add, edit, and delete income/expense transactions
- Filter transactions by type, category, and month
- Categorized transactions with color coding
- Date-based transaction tracking

### 🏷️ Category Management
- Create and manage income/expense categories
- Color-coded categories for better visualization
- Separate management for income and expense categories

### 📈 Reports & Analytics
- Annual overview charts
- Category analysis with polar area charts
- Monthly trend analysis
- Interactive data visualization

### 🎨 Modern UI/UX
- Responsive design that works on all devices
- Beautiful gradient backgrounds
- Smooth animations and transitions
- Intuitive navigation
- Modern card-based layout

## Technology Stack

### Frontend
- **HTML5** - Semantic markup
- **CSS3** - Modern styling with gradients, animations, and responsive design
- **JavaScript (ES6+)** - Interactive functionality
- **Chart.js** - Beautiful data visualization
- **Font Awesome** - Icon library

### Backend
- **PHP 7.4+** - Server-side logic
- **MySQL** - Database management
- **REST API** - Clean API endpoints
- **PDO** - Secure database interactions

## Installation

### Prerequisites
- PHP 7.4 or higher
- MySQL 5.7 or higher
- Web server (Apache/Nginx)

### Setup Instructions

1. **Clone/Download the project**
   ```bash
   git clone <repository-url>
   # or download and extract the ZIP file
   ```

2. **Configure Database**
   - Open `config/database.php`
   - Update database credentials:
     ```php
     define('DB_HOST', 'localhost');
     define('DB_NAME', 'financial_management');
     define('DB_USER', 'your_username');
     define('DB_PASS', 'your_password');
     ```

3. **Run Setup Script**
   ```bash
   php setup.php
   ```
   This will:
   - Create the database
   - Create necessary tables
   - Insert default categories
   - Create a demo user
   - Add sample transactions

4. **Access the Application**
   - Open your web browser
   - Navigate to `http://localhost/your-project-folder/`
   - Login with demo credentials:
     - Username: `demo`
     - Password: `demo123`

## Project Structure

```
financial-management-system/
├── api/
│   ├── auth.php              # Authentication endpoints
│   ├── transactions.php      # Transaction CRUD operations
│   └── categories.php        # Category management
├── assets/
│   ├── css/
│   │   └── style.css         # Main stylesheet
│   └── js/
│       └── app.js            # Main JavaScript functionality
├── config/
│   └── database.php          # Database configuration
├── index.html                # Main application interface
├── setup.php                 # Database setup script
└── README.md                 # This file
```

## API Endpoints

### Authentication
- `POST api/auth.php?action=register` - User registration
- `POST api/auth.php?action=login` - User login

### Transactions
- `GET api/transactions.php?action=list` - Get transactions list
- `GET api/transactions.php?action=stats` - Get statistics
- `POST api/transactions.php?action=add` - Add new transaction
- `PUT api/transactions.php` - Update transaction
- `DELETE api/transactions.php?id={id}` - Delete transaction

### Categories
- `GET api/categories.php` - Get all categories
- `POST api/categories.php` - Create new category
- `PUT api/categories.php` - Update category
- `DELETE api/categories.php?id={id}` - Delete category

## Database Schema

### Users Table
- `id` - Primary key
- `username` - Unique username
- `email` - Unique email address
- `password` - Hashed password
- `created_at` - Timestamp

### Categories Table
- `id` - Primary key
- `name` - Category name
- `type` - 'income' or 'expense'
- `color` - Hex color code
- `created_at` - Timestamp

### Transactions Table
- `id` - Primary key
- `user_id` - Foreign key to users
- `category_id` - Foreign key to categories
- `amount` - Transaction amount
- `description` - Transaction description
- `type` - 'income' or 'expense'
- `date` - Transaction date
- `created_at` - Timestamp

## Usage Guide

### Adding Transactions
1. Click "Add Transaction" button
2. Select transaction type (Income/Expense)
3. Choose category from dropdown
4. Enter amount and description
5. Select date
6. Click Save

### Managing Categories
1. Go to Categories section
2. Click "Add Category"
3. Enter name, select type, and choose color
4. Click Save

### Viewing Reports
1. Navigate to Reports section
2. Select year for annual overview
3. View category analysis charts
4. Analyze spending patterns

### Filtering Transactions
1. Go to Transactions section
2. Use filters to narrow down results:
   - Type (Income/Expense)
   - Category
   - Month
3. Results update automatically

## Customization

### Adding New Categories
Categories can be added through the web interface or by inserting directly into the database:

```sql
INSERT INTO categories (name, type, color) VALUES ('New Category', 'expense', '#ff0000');
```

### Modifying Colors
Update the color scheme by modifying the CSS variables in `assets/css/style.css`:

```css
:root {
    --primary-color: #667eea;
    --secondary-color: #764ba2;
    --success-color: #28a745;
    --danger-color: #dc3545;
}
```

### Adding New Chart Types
Extend the Chart.js functionality by adding new chart configurations in `assets/js/app.js`.

## Security Features

- Password hashing using PHP's `password_hash()`
- SQL injection prevention with prepared statements
- Input validation and sanitization
- CORS headers for API security
- XSS protection with proper output escaping

## Browser Support

- Chrome 60+
- Firefox 55+
- Safari 12+
- Edge 79+

## Troubleshooting

### Common Issues

1. **Database Connection Error**
   - Check database credentials in `config/database.php`
   - Ensure MySQL service is running
   - Verify database exists

2. **Charts Not Loading**
   - Check browser console for JavaScript errors
   - Ensure Chart.js is loaded correctly
   - Verify data format in API responses

3. **Styling Issues**
   - Clear browser cache
   - Check CSS file path
   - Verify Font Awesome CDN connection

### Performance Optimization

- Enable MySQL query caching
- Optimize database indexes
- Use CDN for external resources
- Implement image optimization
- Enable browser caching

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is open source and available under the [MIT License](LICENSE).

## Support

For support and questions:
- Create an issue in the repository
- Check the troubleshooting section
- Review the API documentation

## Future Enhancements

- User authentication and sessions
- Data export functionality
- Budget planning features
- Recurring transactions
- Mobile app version
- Multi-currency support
- Advanced reporting
- Data backup/restore

---

**Note**: This is a demo application. For production use, implement proper user authentication, input validation, and security measures.
